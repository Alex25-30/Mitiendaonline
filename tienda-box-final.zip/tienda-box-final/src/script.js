document.addEventListener("DOMContentLoaded", function () {
    let carrito = [];
    let total = 0;

    function agregarAlCarrito(nombre, precio) {
        let productoExistente = carrito.find(item => item.nombre === nombre);

        if (productoExistente) {
            productoExistente.cantidad++;
        } else {
            carrito.push({ nombre, precio, cantidad: 1 });
        }

        total += precio;
        actualizarCarrito();
        mostrarCarrito();
    }

    function actualizarCarrito() {
        let listaCarrito = document.getElementById("lista-carrito");
        let totalCarrito = document.getElementById("total-carrito");
        let contadorCarrito = document.getElementById("contador-carrito");
        let botonComprar = document.getElementById("boton-comprar");

        if (!listaCarrito || !totalCarrito || !contadorCarrito || !botonComprar) {
            console.error("Error: No se encontraron los elementos del carrito en el HTML.");
            return;
        }

        listaCarrito.innerHTML = "";

        carrito.forEach((item, index) => {
            let li = document.createElement("li");
            li.innerHTML = `
                ${item.nombre} (x${item.cantidad}) - $${item.precio * item.cantidad}
                <button onclick="eliminarDelCarrito(${index})">❌</button>
            `;
            listaCarrito.appendChild(li);
        });

        totalCarrito.textContent = total;
        contadorCarrito.textContent = carrito.length;
        botonComprar.style.display = carrito.length > 0 ? "block" : "none";
    }

    function eliminarDelCarrito(index) {
        let item = carrito[index];

        total -= item.precio * item.cantidad;
        carrito.splice(index, 1);

        actualizarCarrito();
    }

    function vaciarCarrito() {
        carrito = [];
        total = 0;
        actualizarCarrito();
        alert("El carrito ha sido vaciado.");
    }

    function finalizarCompra() {
        if (carrito.length === 0) {
            alert("Tu carrito está vacío.");
            return;
        }

        alert("¡Gracias por tu compra! 🎉🥊");
        vaciarCarrito();
    }

    function mostrarCarrito() {
        document.getElementById("carrito-popup").style.bottom = "0";
    }

    function cerrarCarrito() {
        document.getElementById("carrito-popup").style.bottom = "-100%";
    }

    window.agregarAlCarrito = agregarAlCarrito;
    window.eliminarDelCarrito = eliminarDelCarrito;
    window.vaciarCarrito = vaciarCarrito;
    window.finalizarCompra = finalizarCompra;
    window.mostrarCarrito = mostrarCarrito;
    window.cerrarCarrito = cerrarCarrito;
});
